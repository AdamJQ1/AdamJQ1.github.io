
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/i2c_host/i2c_host_interface.h"
#include <stdint.h>
#include "mcc_generated_files/i2c_host/i2c_host_types.h"
#include "mcc_generated_files/i2c_host/mssp1.h"
#include "mcc_generated_files/i2c_host/i2c_host_event_types.h"
#include "mcc_generated_files/uart/eusart1.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define ADC081C021_I2C_ADDRESS  0x50  // 7-bit address (0x50 = 0b1010000)

static i2c_host_interface_t *i2c = NULL;

void ADC081C021_Init(void)
{
    // Get handle to I2C host instance by name
//    i2c = I2C1_HOST_open("I2C1_Host");  // "I2C1_Host" must match the Custom Name in MCC Melody
    i2c = (i2c_host_interface_t*)&I2C1_Host;
}
uint8_t UART_ReadByte(void)
{
    while(!EUSART1_IsRxReady());  // Wait for data
    return EUSART1_Read();
}
uint8_t ADC081C021_Read(void)
{
    uint8_t regAddr = 0x00;
    uint8_t adcValue = 0;

    if (i2c != NULL)
    {
        i2c->WriteRead(ADC081C021_I2C_ADDRESS, &regAddr, 1, &adcValue, 1);
    }

    return adcValue;
}
// Function to read 8-bit ADC result from ADC081C021

void PrintADCValue(uint8_t value)
{
    char buffer[32];
//    sprintf(buffer, "ADC Value: %u\r\n", value);
    sprintf(buffer, "Raw ADC byte: 0x%02X\r\n", value);
    for (char *p = buffer; *p != '\0'; p++)
    {
        EUSART1_Write(*p);
    }
}



/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    ADC081C021_Init();


    while(1)
    {
        uint8_t adcValue = ADC081C021_Read();
        PrintADCValue(adcValue);
        
        if (EUSART1_IsRxReady())
    {
        uint8_t command = EUSART1_Read();

        if (command == 0xAA)
        {
            LED_Toggle(); // Or LED_Set()/LED_Clear()
        }
    }
        __delay_ms(500); // Add delay between readings
        
    }    
}