/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RB3 aliases
#define tx_TRIS                 TRISBbits.TRISB3
#define tx_LAT                  LATBbits.LATB3
#define tx_PORT                 PORTBbits.RB3
#define tx_WPU                  WPUBbits.WPUB3
#define tx_OD                   ODCONBbits.ODCB3
#define tx_ANS                  ANSELBbits.ANSELB3
#define tx_SetHigh()            do { LATBbits.LATB3 = 1; } while(0)
#define tx_SetLow()             do { LATBbits.LATB3 = 0; } while(0)
#define tx_Toggle()             do { LATBbits.LATB3 = ~LATBbits.LATB3; } while(0)
#define tx_GetValue()           PORTBbits.RB3
#define tx_SetDigitalInput()    do { TRISBbits.TRISB3 = 1; } while(0)
#define tx_SetDigitalOutput()   do { TRISBbits.TRISB3 = 0; } while(0)
#define tx_SetPullup()          do { WPUBbits.WPUB3 = 1; } while(0)
#define tx_ResetPullup()        do { WPUBbits.WPUB3 = 0; } while(0)
#define tx_SetPushPull()        do { ODCONBbits.ODCB3 = 0; } while(0)
#define tx_SetOpenDrain()       do { ODCONBbits.ODCB3 = 1; } while(0)
#define tx_SetAnalogMode()      do { ANSELBbits.ANSELB3 = 1; } while(0)
#define tx_SetDigitalMode()     do { ANSELBbits.ANSELB3 = 0; } while(0)

// get/set RB4 aliases
#define rx_TRIS                 TRISBbits.TRISB4
#define rx_LAT                  LATBbits.LATB4
#define rx_PORT                 PORTBbits.RB4
#define rx_WPU                  WPUBbits.WPUB4
#define rx_OD                   ODCONBbits.ODCB4
#define rx_ANS                  ANSELBbits.ANSELB4
#define rx_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define rx_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define rx_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define rx_GetValue()           PORTBbits.RB4
#define rx_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define rx_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define rx_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define rx_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define rx_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define rx_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define rx_SetAnalogMode()      do { ANSELBbits.ANSELB4 = 1; } while(0)
#define rx_SetDigitalMode()     do { ANSELBbits.ANSELB4 = 0; } while(0)

// get/set RC4 aliases
#define scl_TRIS                 TRISCbits.TRISC4
#define scl_LAT                  LATCbits.LATC4
#define scl_PORT                 PORTCbits.RC4
#define scl_WPU                  WPUCbits.WPUC4
#define scl_OD                   ODCONCbits.ODCC4
#define scl_ANS                  ANSELCbits.ANSELC4
#define scl_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define scl_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define scl_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define scl_GetValue()           PORTCbits.RC4
#define scl_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define scl_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define scl_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define scl_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define scl_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define scl_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define scl_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define scl_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define sda_TRIS                 TRISCbits.TRISC5
#define sda_LAT                  LATCbits.LATC5
#define sda_PORT                 PORTCbits.RC5
#define sda_WPU                  WPUCbits.WPUC5
#define sda_OD                   ODCONCbits.ODCC5
#define sda_ANS                  ANSELCbits.ANSELC5
#define sda_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define sda_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define sda_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define sda_GetValue()           PORTCbits.RC5
#define sda_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define sda_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define sda_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define sda_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define sda_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define sda_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define sda_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define sda_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RD1 aliases
#define LED_TRIS                 TRISDbits.TRISD1
#define LED_LAT                  LATDbits.LATD1
#define LED_PORT                 PORTDbits.RD1
#define LED_WPU                  WPUDbits.WPUD1
#define LED_OD                   ODCONDbits.ODCD1
#define LED_ANS                  ANSELDbits.ANSELD1
#define LED_SetHigh()            do { LATDbits.LATD1 = 1; } while(0)
#define LED_SetLow()             do { LATDbits.LATD1 = 0; } while(0)
#define LED_Toggle()             do { LATDbits.LATD1 = ~LATDbits.LATD1; } while(0)
#define LED_GetValue()           PORTDbits.RD1
#define LED_SetDigitalInput()    do { TRISDbits.TRISD1 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISDbits.TRISD1 = 0; } while(0)
#define LED_SetPullup()          do { WPUDbits.WPUD1 = 1; } while(0)
#define LED_ResetPullup()        do { WPUDbits.WPUD1 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONDbits.ODCD1 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONDbits.ODCD1 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELDbits.ANSELD1 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELDbits.ANSELD1 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/